const cart=[];
const money=n=>"KSh "+Number(n).toFixed(2);
function renderCart(){
 const box=document.getElementById("cart");
 box.innerHTML=cart.length?cart.map((x,i)=>`<div class="cart-row"><div><strong>${escapeHtml(x.name)}</strong><small>${money(x.price)} each</small></div><div class="qty"><button type="button" onclick="changeQty(${i},-1)">−</button><span>${x.quantity}</span><button type="button" onclick="changeQty(${i},1)">+</button></div><b>${money(x.price*x.quantity)}</b><button type="button" class="remove" onclick="removeItem(${i})">×</button></div>`).join(""):'<div class="empty-cart">No items added yet.</div>';
 updateTotals();
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function addItem(btn){
 const type=btn.dataset.type,id=Number(btn.dataset.id),existing=cart.find(x=>x.type===type&&x.id===id);
 if(existing){if(type==="product"&&existing.quantity>=Number(btn.dataset.stock)){alert("No more stock available.");return}existing.quantity++}
 else cart.push({type,id,name:btn.dataset.name,price:Number(btn.dataset.price),stock:type==="product"?Number(btn.dataset.stock):null,quantity:1});
 renderCart();
}
function changeQty(i,d){const x=cart[i],n=x.quantity+d;if(n<=0)return removeItem(i);if(x.type==="product"&&n>x.stock){alert("Quantity exceeds available stock.");return}x.quantity=n;renderCart()}
function removeItem(i){cart.splice(i,1);renderCart()}
function updateTotals(){const s=cart.reduce((a,x)=>a+x.price*x.quantity,0);let d=Number(document.getElementById("discount").value||0);if(d<0)d=0;if(d>s)d=s;document.getElementById("subtotal").textContent=money(s);document.getElementById("total").textContent=money(s-d)}
document.querySelectorAll(".add-item").forEach(b=>b.addEventListener("click",()=>addItem(b)));
document.getElementById("discount").addEventListener("input",updateTotals);
const payment=document.getElementById("payment");
const mpesaFields=document.getElementById("mpesa-fields");
payment.addEventListener("change",()=>{mpesaFields.hidden=payment.value!=="M-PESA";});
function showResult(html){document.getElementById("result").innerHTML=html;}
async function waitForMpesa(statusUrl,receiptNo,total){
 for(let i=0;i<30;i++){
  await new Promise(r=>setTimeout(r,3000));
  try{
   const r=await fetch(statusUrl); const d=await r.json();
   if(d.ok && d.status==="SUCCESS"){
    showResult(`<div class="success-box"><b>M-PESA payment confirmed.</b><br>Receipt: ${escapeHtml(d.receipt_no||receiptNo)}<br>Total: ${money(total)}${d.mpesa_receipt?`<br>M-PESA Receipt: ${escapeHtml(d.mpesa_receipt)}`:""}<br><a href="/receipt/${encodeURIComponent(d.receipt_no||receiptNo)}/pdf" target="_blank">Open PDF Receipt</a></div>`);
    return true;
   }
   if(d.ok && d.status==="FAILED"){showResult(`<div class="flash error">M-PESA payment was not completed. ${escapeHtml(d.result_description||"")}</div>`);return false;}
  }catch(e){}
 }
 showResult(`<div class="flash error">Payment is still pending. Check Sales & Transactions before retrying.</div>`);
 return false;
}
document.getElementById("checkout").addEventListener("click",async()=>{
 const result=document.getElementById("result");if(!cart.length){result.innerHTML='<div class="flash error">Add at least one item.</div>';return}
 const button=document.getElementById("checkout");button.disabled=true;button.textContent=payment.value==="M-PESA"?"Sending M-PESA Prompt...":"Processing...";
 try{
  const body={items:cart.map(x=>({type:x.type,id:x.id,quantity:x.quantity})),discount:Number(document.getElementById("discount").value||0),payment_method:payment.value};
  if(payment.value==="M-PESA") body.phone=document.getElementById("mpesa-phone").value.trim();
  const r=await fetch("/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d=await r.json();if(!d.ok){showResult(`<div class="flash error">${escapeHtml(d.message)}</div>`);return}
  if(d.pending){
   showResult(`<div class="success-box"><b>M-PESA prompt sent.</b><br>Receipt: ${escapeHtml(d.receipt_no)}<br>Total: ${money(d.total)}<br>${escapeHtml(d.message||"Complete the payment on the phone.")}<br><span id="mpesa-wait">Waiting for payment confirmation...</span></div>`);
   await waitForMpesa(d.status_url,d.receipt_no,d.total);
  }else{
   showResult(`<div class="success-box"><b>Sale completed.</b><br>Receipt: ${escapeHtml(d.receipt_no)}<br>Total: ${money(d.total)}<br><a href="${d.pdf_url}" target="_blank">Open PDF Receipt</a></div>`);
  }
  cart.length=0;document.getElementById("discount").value=0;document.getElementById("mpesa-phone").value="";renderCart();
 }catch(e){showResult('<div class="flash error">Could not connect to the server.</div>')}
 finally{button.disabled=false;button.textContent="Complete Sale"}
});
renderCart();
