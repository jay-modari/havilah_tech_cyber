# HAVILAH TECH CYBER SERVICES — Stage 4

Stage 4 is based directly on the Stage 3 project.

## Included
- Professional dashboard with daily sales, expenses and net figures
- POS / New Sale
- Product inventory and stock movements
- Services and prices
- Expenses with date filtering
- Daily sales and transaction history
- Date-range reports with payment methods, daily sales and top items
- Administrator user management
- Settings for business name, contacts, address, logo and receipt branding
- Password change
- SQLite database backup
- PDF receipts generated with ReportLab
- PDF receipt watermark: `HAVILAH TECH CYBER`

## Important
## Default login
Username: `admin`
Password: `admin123`

Change the administrator password from Settings after first login.

## Run in VS Code PowerShell
```powershell
cd "C:\Users\CHILE\Downloads\HAVILAH_TECH_SYSTEM_STAGE4"
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run.py
```
Open: http://127.0.0.1:5000

## EXE note
This is a Flask local desktop-style application. The next packaging stage should bundle a local server and browser launcher rather than simply using `--windowed app.py`.
