"""Safaricom Daraja 3.0 M-PESA Express (STK Push) integration.

Credentials are read only from environment variables. Never hard-code live secrets.
Sandbox is the default; set MPESA_ENV=production only after completing Safaricom's go-live process.
"""
import base64
import os
from datetime import datetime

import requests

SANDBOX_BASE = "https://sandbox.safaricom.co.ke"
PRODUCTION_BASE = "https://api.safaricom.co.ke"


def enabled():
    return bool(os.environ.get("MPESA_CONSUMER_KEY") and os.environ.get("MPESA_CONSUMER_SECRET") and os.environ.get("MPESA_SHORTCODE") and os.environ.get("MPESA_PASSKEY") and os.environ.get("MPESA_CALLBACK_URL"))


def base_url():
    return PRODUCTION_BASE if os.environ.get("MPESA_ENV", "sandbox").lower() == "production" else SANDBOX_BASE


def transaction_type():
    return os.environ.get("MPESA_TRANSACTION_TYPE", "CustomerBuyGoodsOnline")


def merchant_name():
    return os.environ.get("MPESA_MERCHANT_NAME", "Havilah Tech Cyber")


def normalize_phone(phone):
    value = "".join(ch for ch in str(phone or "") if ch.isdigit() or ch == "+")
    if value.startswith("+254"):
        value = "254" + value[4:]
    elif value.startswith("0"):
        value = "254" + value[1:]
    if not (value.startswith("2547") or value.startswith("2541")) or len(value) != 12:
        raise ValueError("Enter a valid Kenyan M-PESA phone number, e.g. 0712345678.")
    return value


def get_access_token():
    key = os.environ.get("MPESA_CONSUMER_KEY", "")
    secret = os.environ.get("MPESA_CONSUMER_SECRET", "")
    if not key or not secret:
        raise RuntimeError("M-PESA Consumer Key and Consumer Secret are not configured.")
    response = requests.get(
        f"{base_url()}/oauth/v1/generate",
        params={"grant_type": "client_credentials"},
        auth=(key, secret),
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    token = payload.get("access_token")
    if not token:
        raise RuntimeError("Daraja did not return an access token.")
    return token


def initiate_stk_push(amount, phone, account_reference, transaction_desc):
    shortcode = os.environ.get("MPESA_SHORTCODE", "").strip()
    passkey = os.environ.get("MPESA_PASSKEY", "").strip()
    callback_url = os.environ.get("MPESA_CALLBACK_URL", "").strip()
    if not shortcode or not passkey or not callback_url:
        raise RuntimeError("M-PESA shortcode, passkey and callback URL are not configured.")

    phone = normalize_phone(phone)
    amount = int(round(float(amount)))
    if amount < 1:
        raise ValueError("M-PESA amount must be at least KSh 1.")

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    password = base64.b64encode(f"{shortcode}{passkey}{timestamp}".encode()).decode()
    token = get_access_token()

    payload = {
        "BusinessShortCode": shortcode,
        "Password": password,
        "Timestamp": timestamp,
        "TransactionType": transaction_type(),
        "Amount": amount,
        "PartyA": phone,
        "PartyB": shortcode,
        "PhoneNumber": phone,
        "CallBackURL": callback_url,
        "AccountReference": str(account_reference)[:12],
        "TransactionDesc": str(transaction_desc)[:13],
    }
    response = requests.post(
        f"{base_url()}/mpesa/stkpush/v1/processrequest",
        json=payload,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()
    if str(data.get("ResponseCode", "")) != "0":
        message = data.get("ResponseDescription") or data.get("errorMessage") or "Daraja rejected the STK Push."
        raise RuntimeError(message)
    return data
