# HAVILAH TECH SYSTEM — Stage 9 Cloud Deployment

This package is prepared for deployment of the Havilah Flask application to Railway with a managed PostgreSQL database, public HTTPS, and the Daraja callback endpoint.

## Important limitation

The deployment itself cannot be completed from this ZIP alone. You must sign in to your own Railway/GitHub accounts and click Deploy/authorize the services. Never put Railway, GitHub, Safaricom Consumer Secret, or Passkey credentials into source code or send them in chat.

## Architecture

Browser/POS -> Railway HTTPS -> Havilah Flask/Gunicorn -> Railway PostgreSQL
                                      |
                                      +-> Safaricom Daraja HTTPS API
                                      +<- /mpesa/callback

## 1. Put the project in GitHub

Create a private GitHub repository and upload all files in this folder. Do NOT upload a `.env` file containing real credentials.

## 2. Create the Railway project

1. Open Railway and create a new project.
2. Choose Deploy from GitHub repo and select the Havilah repository.
3. Add a PostgreSQL database service from `+ New` -> `Database` -> `PostgreSQL`.
4. In the Havilah web service Variables, create:

`DATABASE_URL=${{Postgres.DATABASE_URL}}`

If your PostgreSQL service has a different name, replace `Postgres` with that service name.

## 3. Required Havilah variables

Set these in the web service Variables tab:

```text
DATABASE_URL=${{Postgres.DATABASE_URL}}
HAVILAH_SECRET_KEY=<generate-a-long-random-secret>
SESSION_COOKIE_SECURE=1
SESSION_COOKIE_SAMESITE=Lax
MPESA_ENV=sandbox
MPESA_SHORTCODE=9240308
MPESA_MERCHANT_NAME=Godfrey Ochelle
MPESA_TRANSACTION_TYPE=CustomerBuyGoodsOnline
MPESA_CONSUMER_KEY=<your-Daraja-sandbox-key>
MPESA_CONSUMER_SECRET=<your-Daraja-sandbox-secret>
MPESA_PASSKEY=<your-Daraja-sandbox-passkey>
MPESA_CALLBACK_URL=https://<your-public-domain>/mpesa/callback
```

Do not set `PORT` manually unless you have a specific reason; Railway supplies it to the service.

## 4. Deploy and verify

Railway should detect the Python application and use the `railway.json` start command. After deployment, generate a Railway public domain under the web service's Networking settings.

Open:

`https://<your-public-domain>/health`

Expected response:

```json
{"status":"ok"}
```

Then open the main URL and test login/POS.

## 5. Configure Daraja callback

After the public HTTPS domain exists, set:

`MPESA_CALLBACK_URL=https://<your-public-domain>/mpesa/callback`

Redeploy the service after changing the variable.

Use the official Safaricom Daraja portal to create/configure the sandbox application and obtain its sandbox credentials. Do not use production credentials for sandbox testing.

## 6. Custom domain

If you own a domain, add it under Railway Service -> Settings -> Networking -> Custom Domain. Railway supplies the required DNS records. Add both the CNAME routing record and TXT verification record exactly as Railway shows, then wait for verification and SSL issuance.

Example desired URL:

`https://app.yourdomain.co.ke`

Once the custom domain is active, change `MPESA_CALLBACK_URL` to the custom HTTPS URL and redeploy.

## 7. PostgreSQL

Keep PostgreSQL private. The Havilah web service should connect through Railway's private service reference. Do not expose the database publicly unless you have a specific administrative need.

## 8. Production checklist

Before switching `MPESA_ENV` to `production`:

- Confirm PostgreSQL is working and data has been backed up.
- Change the default admin password.
- Generate a strong `HAVILAH_SECRET_KEY`.
- Confirm HTTPS works.
- Confirm `/health` returns 200.
- Test cash/card/bank sales.
- Test M-PESA sandbox callbacks.
- Confirm a successful M-PESA callback changes the sale to PAID and deducts stock exactly once.
- Confirm failed/cancelled M-PESA payments do not reduce stock.
- Complete Safaricom's production/go-live requirements for the Till before using real payments.

## 9. Local deployment helper

If using Railway CLI from Windows PowerShell:

```powershell
railway login
railway init
railway add -d postgres
railway up
railway domain
```

For a GitHub deployment, the dashboard route is usually easier for the first deployment.
