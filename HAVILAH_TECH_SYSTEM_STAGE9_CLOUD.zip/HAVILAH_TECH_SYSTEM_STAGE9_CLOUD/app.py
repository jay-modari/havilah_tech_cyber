import os
import uuid
import json
from datetime import datetime, date
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader

from database import get_db, init_db, get_settings, DB_ERROR, DB_INTEGRITY_ERROR
import mpesa

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("HAVILAH_SECRET_KEY", "change-this-secret-key-before-deployment")
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = os.environ.get("SESSION_COOKIE_SAMESITE", "Lax")
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("SESSION_COOKIE_SECURE", "0").lower() in {"1", "true", "yes"}
init_db()

@app.context_processor
def inject_settings():
    try:
        return {"app_settings": get_settings()}
    except Exception:
        return {"app_settings": {}}

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "Administrator":
            flash("Administrator access is required.", "error")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped

def make_receipt_no():
    return "HT-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4].upper()

def parse_date(value, fallback):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return fallback

@app.route("/health")
def health():
    try:
        db = get_db()
        db.execute("SELECT 1").fetchone()
        db.close()
        return jsonify({"status": "ok"})
    except Exception:
        return jsonify({"status": "error"}), 503

@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=? AND is_active=1", (username,)).fetchone()
        db.close()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    stats = {
        "sales_today": db.execute("SELECT COALESCE(SUM(total),0) value FROM sales WHERE date(created_at)=CURRENT_DATE AND payment_status='PAID'").fetchone()["value"],
        "transactions_today": db.execute("SELECT COUNT(*) value FROM sales WHERE date(created_at)=CURRENT_DATE AND payment_status='PAID'").fetchone()["value"],
        "products": db.execute("SELECT COUNT(*) value FROM products WHERE is_active=1").fetchone()["value"],
        "services": db.execute("SELECT COUNT(*) value FROM services WHERE is_active=1").fetchone()["value"],
        "expenses_today": db.execute("SELECT COALESCE(SUM(amount),0) value FROM expenses WHERE date(created_at)=CURRENT_DATE").fetchone()["value"],
    }
    stats["net_today"] = stats["sales_today"] - stats["expenses_today"]
    low_stock = db.execute("SELECT * FROM products WHERE is_active=1 AND stock_qty <= low_stock_level ORDER BY stock_qty").fetchall()
    recent = db.execute("""SELECT s.*, COALESCE(u.full_name,'-') cashier
                           FROM sales s LEFT JOIN users u ON u.id=s.created_by
                           ORDER BY s.id DESC LIMIT 8""").fetchall()
    db.close()
    return render_template("dashboard.html", stats=stats, low_stock=low_stock, recent=recent)

@app.route("/pos")
@login_required
def pos():
    db = get_db()
    products = db.execute("SELECT * FROM products WHERE is_active=1 AND stock_qty>0 ORDER BY name").fetchall()
    services = db.execute("SELECT * FROM services WHERE is_active=1 ORDER BY name").fetchall()
    db.close()
    return render_template("pos.html", products=products, services=services)

def _validate_sale_items(db, items):
    if not items:
        raise ValueError("Cart is empty.")
    clean_items = []
    subtotal = 0.0
    for raw in items:
        item_type = raw.get("type")
        item_id = int(raw.get("id"))
        quantity = float(raw.get("quantity", 0))
        if item_type not in {"product", "service"} or quantity <= 0:
            raise ValueError("Invalid sale item.")
        if item_type == "product":
            row = db.execute("SELECT id,name,price,stock_qty FROM products WHERE id=? AND is_active=1", (item_id,)).fetchone()
            if not row:
                raise ValueError("Product not found.")
            if quantity > float(row["stock_qty"]):
                raise ValueError(f"Insufficient stock for {row['name']}.")
        else:
            row = db.execute("SELECT id,name,price FROM services WHERE id=? AND is_active=1", (item_id,)).fetchone()
            if not row:
                raise ValueError("Service not found.")
        line = float(row["price"]) * quantity
        subtotal += line
        clean_items.append((item_type, row["id"], row["name"], quantity, float(row["price"]), line))
    return clean_items, subtotal

def _insert_sale(db, clean_items, subtotal, discount, payment_method, payment_status="PAID", mpesa_phone=""):
    receipt_no = make_receipt_no()
    cur = db.execute("""INSERT INTO sales
        (receipt_no,subtotal,discount,total,payment_method,payment_status,mpesa_phone,created_by)
        VALUES(?,?,?,?,?,?,?,?) RETURNING id""",
        (receipt_no, subtotal, discount, subtotal - discount, payment_method, payment_status, mpesa_phone, session["user_id"]))
    sale_id = cur.fetchone()["id"]
    for item_type, item_id, name, quantity, price, line in clean_items:
        db.execute("""INSERT INTO sale_items
            (sale_id,item_type,item_id,item_name,quantity,unit_price,line_total)
            VALUES(?,?,?,?,?,?,?)""",
            (sale_id, item_type, item_id, name, quantity, price, line))
    return sale_id, receipt_no, subtotal - discount

def _complete_stock_for_sale(db, sale_id, receipt_no):
    rows = db.execute("SELECT item_type,item_id,quantity FROM sale_items WHERE sale_id=?", (sale_id,)).fetchall()
    for item in rows:
        if item["item_type"] != "product":
            continue
        row = db.execute("SELECT stock_qty,name FROM products WHERE id=? AND is_active=1", (item["item_id"],)).fetchone()
        if not row or float(item["quantity"]) > float(row["stock_qty"]):
            raise ValueError(f"Insufficient stock for {row['name'] if row else 'product'}.")
        new_balance = float(row["stock_qty"]) - float(item["quantity"])
        db.execute("UPDATE products SET stock_qty=? WHERE id=?", (new_balance, item["item_id"]))
        db.execute("""INSERT INTO stock_movements
            (product_id,movement_type,quantity,balance_after,reference,notes,created_by)
            VALUES(?,?,?,?,?,?,?)""",
            (item["item_id"], "SALE", -float(item["quantity"]), new_balance, receipt_no, "POS sale - M-PESA confirmed", session.get("user_id")))

def _start_mpesa_sale(data):
    phone = data.get("phone") or data.get("mpesa_phone")
    db = get_db()
    try:
        clean_items, subtotal = _validate_sale_items(db, data.get("items", []))
        discount = max(0, float(data.get("discount", 0) or 0))
        discount = min(discount, subtotal)
        sale_id, receipt_no, total = _insert_sale(db, clean_items, subtotal, discount, "M-PESA", "PENDING", mpesa.normalize_phone(phone))
        db.commit()

        try:
            response = mpesa.initiate_stk_push(total, phone, receipt_no, "Havilah POS")
        except Exception as exc:
            db.execute("UPDATE sales SET payment_status='FAILED' WHERE id=?", (sale_id,))
            db.commit()
            return {"ok": False, "message": str(exc) or "Could not send M-PESA prompt."}

        checkout_id = response.get("CheckoutRequestID", "")
        merchant_id = response.get("MerchantRequestID", "")
        if not checkout_id:
            db.execute("UPDATE sales SET payment_status='FAILED' WHERE id=?", (sale_id,))
            db.commit()
            return {"ok": False, "message": "Daraja did not return a CheckoutRequestID."}
        db.execute("""INSERT INTO mpesa_transactions
            (sale_id,merchant_request_id,checkout_request_id,phone,amount,status)
            VALUES(?,?,?,?,?,?)""",
            (sale_id, merchant_id, checkout_id, mpesa.normalize_phone(phone), total, "PENDING"))
        db.commit()
        return {"ok": True, "pending": True, "receipt_no": receipt_no, "total": total,
                "checkout_request_id": checkout_id, "message": response.get("CustomerMessage") or "M-PESA prompt sent. Enter your PIN on the customer's phone.",
                "status_url": url_for("mpesa_status", checkout_request_id=checkout_id)}
    except (ValueError, TypeError, DB_ERROR) as exc:
        db.rollback()
        return {"ok": False, "message": str(exc) or "M-PESA sale could not be started."}
    finally:
        db.close()

@app.route("/checkout", methods=["POST"])
@login_required
def checkout():
    data = request.get_json(silent=True) or {}
    items = data.get("items", [])
    payment_method = data.get("payment_method", "Cash")
    try:
        discount = max(0, float(data.get("discount", 0) or 0))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "message": "Invalid discount."}), 400
    if not items:
        return jsonify({"ok": False, "message": "Cart is empty."}), 400
    if payment_method not in {"Cash", "M-PESA", "Card", "Bank"}:
        return jsonify({"ok": False, "message": "Invalid payment method."}), 400
    if payment_method == "M-PESA":
        result = _start_mpesa_sale(data)
        return jsonify(result), (400 if not result.get("ok") else 200)

    db = get_db()
    try:
        clean_items = []
        subtotal = 0.0
        for raw in items:
            item_type = raw.get("type")
            item_id = int(raw.get("id"))
            quantity = float(raw.get("quantity", 0))
            if item_type not in {"product", "service"} or quantity <= 0:
                raise ValueError("Invalid sale item.")
            if item_type == "product":
                row = db.execute("SELECT id,name,price,stock_qty FROM products WHERE id=? AND is_active=1", (item_id,)).fetchone()
                if not row:
                    raise ValueError("Product not found.")
                if quantity > row["stock_qty"]:
                    raise ValueError(f"Insufficient stock for {row['name']}.")
            else:
                row = db.execute("SELECT id,name,price FROM services WHERE id=? AND is_active=1", (item_id,)).fetchone()
                if not row:
                    raise ValueError("Service not found.")
            line = float(row["price"]) * quantity
            subtotal += line
            clean_items.append((item_type, row["id"], row["name"], quantity, float(row["price"]), line))

        discount = min(discount, subtotal)
        total = subtotal - discount
        receipt_no = make_receipt_no()
        cur = db.execute("""INSERT INTO sales
            (receipt_no,subtotal,discount,total,payment_method,created_by)
            VALUES(?,?,?,?,?,?) RETURNING id""",
            (receipt_no, subtotal, discount, total, payment_method, session["user_id"]))
        sale_id = cur.fetchone()["id"]

        for item_type, item_id, name, quantity, price, line in clean_items:
            db.execute("""INSERT INTO sale_items
                (sale_id,item_type,item_id,item_name,quantity,unit_price,line_total)
                VALUES(?,?,?,?,?,?,?)""",
                (sale_id, item_type, item_id, name, quantity, price, line))
            if item_type == "product":
                row = db.execute("SELECT stock_qty FROM products WHERE id=?", (item_id,)).fetchone()
                new_balance = float(row["stock_qty"]) - quantity
                db.execute("UPDATE products SET stock_qty=? WHERE id=?", (new_balance, item_id))
                db.execute("""INSERT INTO stock_movements
                    (product_id,movement_type,quantity,balance_after,reference,notes,created_by)
                    VALUES(?,?,?,?,?,?,?)""",
                    (item_id, "SALE", -quantity, new_balance, receipt_no, "POS sale", session["user_id"]))
        db.commit()
        return jsonify({"ok": True, "receipt_no": receipt_no, "total": total, "pdf_url": url_for("receipt_pdf", receipt_no=receipt_no)})
    except (ValueError, TypeError, DB_ERROR) as exc:
        db.rollback()
        return jsonify({"ok": False, "message": str(exc) or "Sale could not be completed."}), 400
    finally:
        db.close()

@app.route("/mpesa/status/<checkout_request_id>")
@login_required
def mpesa_status(checkout_request_id):
    db = get_db()
    tx = db.execute("""SELECT m.*, s.receipt_no, s.payment_status
                      FROM mpesa_transactions m JOIN sales s ON s.id=m.sale_id
                      WHERE m.checkout_request_id=?""", (checkout_request_id,)).fetchone()
    db.close()
    if not tx:
        return jsonify({"ok": False, "message": "M-PESA transaction not found."}), 404
    return jsonify({"ok": True, "status": tx["status"], "payment_status": tx["payment_status"],
                    "receipt_no": tx["receipt_no"], "mpesa_receipt": tx["mpesa_receipt"] or "",
                    "result_description": tx["result_description"] or ""})

@app.route("/mpesa/callback", methods=["POST"])
def mpesa_callback():
    payload = request.get_json(silent=True) or {}
    callback = payload.get("Body", {}).get("stkCallback", {})
    checkout_id = callback.get("CheckoutRequestID")
    if not checkout_id:
        return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

    result_code = str(callback.get("ResultCode", ""))
    result_desc = callback.get("ResultDesc", "")
    metadata = {}
    for item in callback.get("CallbackMetadata", {}).get("Item", []) or []:
        name = item.get("Name")
        if name:
            metadata[name] = item.get("Value")
    receipt = str(metadata.get("MpesaReceiptNumber", "") or "")

    db = get_db()
    try:
        tx = db.execute("SELECT * FROM mpesa_transactions WHERE checkout_request_id=?", (checkout_id,)).fetchone()
        if not tx:
            # Daraja callbacks are asynchronous; return success so Safaricom does not
            # repeatedly retry while the app is still finishing the initiating request.
            db.close()
            return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

        if tx["status"] != "PENDING":
            db.close()
            return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

        if result_code == "0":
            sale = db.execute("SELECT * FROM sales WHERE id=?", (tx["sale_id"],)).fetchone()
            if not sale:
                raise ValueError("Linked sale no longer exists.")
            if sale["payment_status"] != "PAID":
                _complete_stock_for_sale(db, tx["sale_id"], sale["receipt_no"])
                db.execute("UPDATE sales SET payment_status='PAID', mpesa_receipt=? WHERE id=?", (receipt, tx["sale_id"]))
            db.execute("""UPDATE mpesa_transactions SET status='SUCCESS', mpesa_receipt=?, result_code=?, result_description=?, raw_callback=?, updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                       (receipt, result_code, result_desc, json.dumps(payload)[:10000], tx["id"]))
        else:
            db.execute("""UPDATE sales SET payment_status='FAILED' WHERE id=? AND payment_status='PENDING'""", (tx["sale_id"],))
            db.execute("""UPDATE mpesa_transactions SET status='FAILED', result_code=?, result_description=?, raw_callback=?, updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                       (result_code, result_desc, json.dumps(payload)[:10000], tx["id"]))
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()
    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

@app.route("/receipt/<receipt_no>")
@login_required
def receipt(receipt_no):
    db = get_db()
    sale = db.execute("""SELECT s.*, COALESCE(u.full_name,'-') cashier
                         FROM sales s LEFT JOIN users u ON u.id=s.created_by
                         WHERE s.receipt_no=?""", (receipt_no,)).fetchone()
    if not sale:
        db.close()
        flash("Receipt not found.", "error")
        return redirect(url_for("sales"))
    items = db.execute("SELECT * FROM sale_items WHERE sale_id=? ORDER BY id", (sale["id"],)).fetchall()
    settings = get_settings(db)
    db.close()
    return render_template("receipt.html", sale=sale, items=items, cashier=sale["cashier"], settings=settings)

@app.route("/receipt/<receipt_no>/pdf")
@login_required
def receipt_pdf(receipt_no):
    db = get_db()
    sale = db.execute("""SELECT s.*, COALESCE(u.full_name,'-') cashier
                         FROM sales s LEFT JOIN users u ON u.id=s.created_by
                         WHERE s.receipt_no=?""", (receipt_no,)).fetchone()
    if not sale:
        db.close()
        flash("Receipt not found.", "error")
        return redirect(url_for("sales"))
    items = db.execute("SELECT * FROM sale_items WHERE sale_id=? ORDER BY id", (sale["id"],)).fetchall()
    settings = get_settings(db)
    db.close()

    pdf_path = Path(app.root_path) / "data" / f"{receipt_no}.pdf"
    pdf_path.parent.mkdir(exist_ok=True)
    c = canvas.Canvas(str(pdf_path), pagesize=A4)
    width, height = A4

    c.saveState()
    c.setFont("Helvetica-Bold", 34)
    c.setFillGray(0.88)
    c.translate(width / 2, height / 2)
    c.rotate(35)
    c.drawCentredString(0, 0, settings.get("receipt_watermark") or "HAVILAH TECH CYBER")
    c.restoreState()

    y = height - 48
    logo = settings.get("logo_filename")
    logo_path = UPLOAD_DIR / logo if logo else None
    if logo_path and logo_path.exists():
        try:
            c.drawImage(ImageReader(str(logo_path)), 40, y-42, width=55, height=55, preserveAspectRatio=True, mask="auto")
            x = 105
        except Exception:
            x = 40
    else:
        x = 40
    c.setFillGray(0)
    c.setFont("Helvetica-Bold", 17)
    c.drawString(x, y, settings.get("business_name") or "HAVILAH TECH CYBER SERVICES")
    c.setFont("Helvetica", 9)
    contact = " | ".join(v for v in [settings.get("business_phone"), settings.get("business_email"), settings.get("business_address")] if v)
    if contact:
        c.drawString(x, y-15, contact[:120])

    y -= 78
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40, y, "SALES RECEIPT")
    y -= 20
    c.setFont("Helvetica", 9)
    c.drawString(40, y, f"Receipt: {sale['receipt_no']}")
    c.drawRightString(width-40, y, f"Date: {sale['created_at']}")
    y -= 14
    c.drawString(40, y, f"Cashier: {sale['cashier']}")
    y -= 28

    c.setFont("Helvetica-Bold", 9)
    c.drawString(40, y, "ITEM")
    c.drawRightString(width-290, y, "QTY")
    c.drawRightString(width-190, y, "PRICE")
    c.drawRightString(width-40, y, "TOTAL")
    y -= 6
    c.line(40, y, width-40, y)
    y -= 18

    c.setFont("Helvetica", 9)
    for item in items:
        if y < 110:
            c.showPage()
            y = height - 50
        name = str(item["item_name"])[:45]
        c.drawString(40, y, name)
        c.drawRightString(width-290, y, f"{item['quantity']:g}")
        c.drawRightString(width-190, y, f"KSh {item['unit_price']:,.2f}")
        c.drawRightString(width-40, y, f"KSh {item['line_total']:,.2f}")
        y -= 17

    y -= 5
    c.line(width-250, y, width-40, y)
    y -= 18
    c.drawRightString(width-40, y, f"Subtotal: KSh {sale['subtotal']:,.2f}")
    y -= 16
    c.drawRightString(width-40, y, f"Discount: KSh {sale['discount']:,.2f}")
    y -= 18
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(width-40, y, f"TOTAL: KSh {sale['total']:,.2f}")
    y -= 18
    c.setFont("Helvetica", 9)
    c.drawRightString(width-40, y, f"Payment: {sale['payment_method']} ({sale['payment_status']})")
    y -= 16
    if sale.get("mpesa_receipt"):
        c.drawRightString(width-40, y, f"M-PESA Receipt: {sale['mpesa_receipt']}")
        y -= 16
    y -= 20
    c.drawCentredString(width/2, max(y, 45), settings.get("receipt_footer") or "Thank you for your business.")
    c.save()
    return send_file(str(pdf_path), as_attachment=False, download_name=f"{receipt_no}.pdf", mimetype="application/pdf")

@app.route("/sales")
@login_required
def sales():
    today = date.today()
    start = parse_date(request.args.get("start"), today)
    end = parse_date(request.args.get("end"), today)
    if start > end:
        start, end = end, start
    db = get_db()
    rows = db.execute("""SELECT s.*, COALESCE(u.full_name,'-') cashier
                        FROM sales s LEFT JOIN users u ON u.id=s.created_by
                        WHERE date(s.created_at) BETWEEN ? AND ?
                        ORDER BY s.id DESC""", (start.isoformat(), end.isoformat())).fetchall()
    summary = db.execute("""SELECT COALESCE(SUM(total),0) total, COUNT(*) transactions
                            FROM sales WHERE date(created_at) BETWEEN ? AND ? AND payment_status='PAID'""",
                         (start.isoformat(), end.isoformat())).fetchone()
    db.close()
    return render_template("sales.html", sales=rows, start=start.isoformat(), end=end.isoformat(), summary=summary)

@app.route("/inventory")
@login_required
def inventory():
    db = get_db()
    products = db.execute("SELECT * FROM products WHERE is_active=1 ORDER BY name").fetchall()
    db.close()
    return render_template("inventory.html", products=products)

@app.route("/inventory/add", methods=["POST"])
@login_required
def add_product():
    try:
        name = request.form["name"].strip()
        sku = request.form.get("sku","").strip()
        price = float(request.form["price"])
        stock_qty = float(request.form.get("stock_qty",0))
        low_stock_level = float(request.form.get("low_stock_level",5))
        if not name or price < 0 or stock_qty < 0 or low_stock_level < 0:
            raise ValueError
    except (KeyError, ValueError):
        flash("Enter valid product details.", "error")
        return redirect(url_for("inventory"))
    db = get_db()
    try:
        cur = db.execute("""INSERT INTO products(name,sku,price,stock_qty,low_stock_level)
                            VALUES(?,?,?,?,?) RETURNING id""",
                         (name,sku,price,stock_qty,low_stock_level))
        product_id = cur.fetchone()["id"]
        if stock_qty:
            db.execute("""INSERT INTO stock_movements
                (product_id,movement_type,quantity,balance_after,reference,notes,created_by)
                VALUES(?,?,?,?,?,?,?)""",
                (product_id,"OPENING",stock_qty,stock_qty,"OPENING","Opening stock",session["user_id"]))
        db.commit()
        flash("Product added.", "success")
    except DB_INTEGRITY_ERROR:
        db.rollback()
        flash("A product with that name already exists.", "error")
    finally:
        db.close()
    return redirect(url_for("inventory"))

@app.route("/inventory/edit/<int:product_id>", methods=["POST"])
@login_required
def edit_product(product_id):
    try:
        name=request.form["name"].strip(); sku=request.form.get("sku","").strip()
        price=float(request.form["price"]); low=float(request.form["low_stock_level"])
        if not name or price < 0 or low < 0: raise ValueError
    except (KeyError,ValueError):
        flash("Invalid product details.", "error"); return redirect(url_for("inventory"))
    db=get_db()
    try:
        db.execute("UPDATE products SET name=?,sku=?,price=?,low_stock_level=? WHERE id=?",
                   (name,sku,price,low,product_id))
        db.commit(); flash("Product updated.","success")
    except DB_INTEGRITY_ERROR:
        db.rollback(); flash("Product name already exists.","error")
    finally: db.close()
    return redirect(url_for("inventory"))

@app.route("/inventory/adjust/<int:product_id>", methods=["POST"])
@login_required
def adjust_stock(product_id):
    try:
        movement_type=request.form["movement_type"]
        qty=float(request.form["quantity"]); notes=request.form.get("notes","").strip()
        if qty <= 0 or movement_type not in {"RESTOCK","RETURN","DAMAGE","CORRECTION"}: raise ValueError
    except (KeyError,ValueError):
        flash("Invalid stock adjustment.","error"); return redirect(url_for("inventory"))
    db=get_db()
    row=db.execute("SELECT stock_qty FROM products WHERE id=? AND is_active=1",(product_id,)).fetchone()
    if not row:
        db.close(); flash("Product not found.","error"); return redirect(url_for("inventory"))
    old=float(row["stock_qty"])
    signed=qty if movement_type in {"RESTOCK","RETURN"} else -qty
    new=old+signed
    if new < 0:
        db.close(); flash("Stock cannot go below zero.","error"); return redirect(url_for("inventory"))
    db.execute("UPDATE products SET stock_qty=? WHERE id=?",(new,product_id))
    db.execute("""INSERT INTO stock_movements
        (product_id,movement_type,quantity,balance_after,reference,notes,created_by)
        VALUES(?,?,?,?,?,?,?)""",(product_id,movement_type,signed,new,"MANUAL",notes,session["user_id"]))
    db.commit(); db.close()
    flash("Stock adjusted.","success"); return redirect(url_for("inventory"))

@app.route("/inventory/movements")
@login_required
def stock_movements():
    db=get_db()
    rows=db.execute("""SELECT m.*,p.name product_name,COALESCE(u.full_name,'-') user_name
                       FROM stock_movements m JOIN products p ON p.id=m.product_id
                       LEFT JOIN users u ON u.id=m.created_by ORDER BY m.id DESC LIMIT 300""").fetchall()
    db.close()
    return render_template("stock_movements.html", movements=rows)

@app.route("/services")
@login_required
def services():
    db=get_db(); rows=db.execute("SELECT * FROM services WHERE is_active=1 ORDER BY name").fetchall(); db.close()
    return render_template("services.html", services=rows)

@app.route("/services/add", methods=["POST"])
@login_required
def add_service():
    try:
        name=request.form["name"].strip(); description=request.form.get("description","").strip(); price=float(request.form["price"])
        if not name or price<0: raise ValueError
    except (KeyError,ValueError):
        flash("Enter valid service details.","error"); return redirect(url_for("services"))
    db=get_db()
    try:
        db.execute("INSERT INTO services(name,description,price) VALUES(?,?,?)",(name,description,price)); db.commit()
        flash("Service added.","success")
    except DB_INTEGRITY_ERROR:
        db.rollback(); flash("A service with that name already exists.","error")
    finally: db.close()
    return redirect(url_for("services"))

@app.route("/services/edit/<int:service_id>", methods=["POST"])
@login_required
def edit_service(service_id):
    try:
        name=request.form["name"].strip(); description=request.form.get("description","").strip(); price=float(request.form["price"])
        if not name or price<0: raise ValueError
    except (KeyError,ValueError):
        flash("Enter valid service details.","error"); return redirect(url_for("services"))
    db=get_db()
    try:
        db.execute("UPDATE services SET name=?,description=?,price=? WHERE id=?",(name,description,price,service_id)); db.commit()
        flash("Service updated.","success")
    except DB_INTEGRITY_ERROR:
        db.rollback(); flash("Service name already exists.","error")
    finally: db.close()
    return redirect(url_for("services"))

@app.route("/expenses")
@login_required
def expenses():
    start=parse_date(request.args.get("start"),date.today()); end=parse_date(request.args.get("end"),date.today())
    if start>end: start,end=end,start
    db=get_db()
    rows=db.execute("""SELECT e.*,COALESCE(u.full_name,'-') user_name FROM expenses e
                       LEFT JOIN users u ON u.id=e.created_by
                       WHERE date(e.created_at) BETWEEN ? AND ? ORDER BY e.id DESC""",
                    (start.isoformat(),end.isoformat())).fetchall()
    total=db.execute("SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE date(created_at) BETWEEN ? AND ?",
                     (start.isoformat(),end.isoformat())).fetchone()["total"]
    db.close()
    return render_template("expenses.html", expenses=rows, total=total, start=start.isoformat(), end=end.isoformat())

@app.route("/expenses/add", methods=["POST"])
@login_required
def add_expense():
    try:
        description=request.form["description"].strip(); category=request.form.get("category","").strip(); amount=float(request.form["amount"])
        if not description or amount<=0: raise ValueError
    except (KeyError,ValueError):
        flash("Enter a valid expense.","error"); return redirect(url_for("expenses"))
    db=get_db(); db.execute("INSERT INTO expenses(description,amount,category,created_by) VALUES(?,?,?,?)",
                            (description,amount,category,session["user_id"])); db.commit(); db.close()
    flash("Expense recorded.","success"); return redirect(url_for("expenses"))

@app.route("/users")
@login_required
@admin_required
def users():
    db=get_db(); rows=db.execute("SELECT id,username,full_name,role,is_active,created_at FROM users ORDER BY username").fetchall(); db.close()
    return render_template("users.html", users=rows)

@app.route("/users/add", methods=["POST"])
@login_required
@admin_required
def add_user():
    username=request.form.get("username","").strip(); full_name=request.form.get("full_name","").strip()
    password=request.form.get("password",""); role=request.form.get("role","Cashier")
    if not username or not full_name or len(password)<6 or role not in {"Administrator","Manager","Cashier"}:
        flash("Use a username, full name, password of at least 6 characters, and valid role.","error"); return redirect(url_for("users"))
    db=get_db()
    try:
        db.execute("INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?,?)",
                   (username,generate_password_hash(password),full_name,role)); db.commit(); flash("User created.","success")
    except DB_INTEGRITY_ERROR:
        db.rollback(); flash("Username already exists.","error")
    finally: db.close()
    return redirect(url_for("users"))

@app.route("/users/toggle/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def toggle_user(user_id):
    if user_id==session["user_id"]:
        flash("You cannot deactivate your own account.","error"); return redirect(url_for("users"))
    db=get_db(); db.execute("UPDATE users SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END WHERE id=?",(user_id,))
    db.commit(); db.close(); flash("User status changed.","success"); return redirect(url_for("users"))

@app.route("/reports")
@login_required
def reports():
    start=parse_date(request.args.get("start"),date.today()); end=parse_date(request.args.get("end"),date.today())
    if start>end: start,end=end,start
    db=get_db()
    sales_summary=db.execute("""SELECT COALESCE(SUM(total),0) total_sales,COUNT(*) transactions
                                FROM sales WHERE date(created_at) BETWEEN ? AND ? AND payment_status='PAID'""",
                             (start.isoformat(),end.isoformat())).fetchone()
    expense_total=db.execute("""SELECT COALESCE(SUM(amount),0) total_expenses
                                FROM expenses WHERE date(created_at) BETWEEN ? AND ?""",
                             (start.isoformat(),end.isoformat())).fetchone()["total_expenses"]
    payments=db.execute("""SELECT payment_method,COUNT(*) transactions,COALESCE(SUM(total),0) total
                           FROM sales WHERE date(created_at) BETWEEN ? AND ? AND payment_status='PAID'
                           GROUP BY payment_method ORDER BY total DESC""",
                        (start.isoformat(),end.isoformat())).fetchall()
    top_items=db.execute("""SELECT item_name,SUM(quantity) qty,SUM(line_total) revenue
                            FROM sale_items JOIN sales ON sales.id=sale_items.sale_id
                            WHERE date(sales.created_at) BETWEEN ? AND ? AND sales.payment_status='PAID'
                            GROUP BY item_name ORDER BY revenue DESC LIMIT 10""",
                         (start.isoformat(),end.isoformat())).fetchall()
    daily=db.execute("""SELECT date(created_at) day,COUNT(*) transactions,COALESCE(SUM(total),0) total
                        FROM sales WHERE date(created_at) BETWEEN ? AND ? AND payment_status='PAID'
                        GROUP BY date(created_at) ORDER BY day DESC""",
                     (start.isoformat(),end.isoformat())).fetchall()
    db.close()
    net=float(sales_summary["total_sales"])-float(expense_total)
    return render_template("reports.html", report=sales_summary, expense_total=expense_total,
                           net=net,payments=payments,top_items=top_items,daily=daily,
                           start=start.isoformat(),end=end.isoformat())

@app.route("/settings", methods=["GET","POST"])
@login_required
@admin_required
def settings():
    db=get_db()
    if request.method=="POST":
        fields=["business_name","business_phone","business_email","business_address","receipt_footer","receipt_watermark"]
        for key in fields:
            value=request.form.get(key,"").strip()
            if key=="receipt_watermark" and not value:
                value="HAVILAH TECH CYBER"
            db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,value))
        logo=request.files.get("logo")
        if logo and logo.filename:
            ext=Path(secure_filename(logo.filename)).suffix.lower()
            if ext not in {".png",".jpg",".jpeg",".webp"}:
                db.close(); flash("Logo must be PNG, JPG, JPEG or WEBP.","error"); return redirect(url_for("settings"))
            filename="logo"+ext
            logo.save(UPLOAD_DIR/filename)
            db.execute("INSERT INTO settings(key,value) VALUES('logo_filename',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(filename,))
        db.commit(); flash("Settings saved.","success")
    settings_data=get_settings(db); db.close()
    return render_template("settings.html", settings=settings_data)

@app.route("/settings/password", methods=["POST"])
@login_required
def change_password():
    current=request.form.get("current_password",""); new=request.form.get("new_password",""); confirm=request.form.get("confirm_password","")
    if len(new)<6 or new!=confirm:
        flash("New passwords must match and contain at least 6 characters.","error"); return redirect(url_for("settings"))
    db=get_db(); user=db.execute("SELECT password_hash FROM users WHERE id=?",(session["user_id"],)).fetchone()
    if not user or not check_password_hash(user["password_hash"],current):
        db.close(); flash("Current password is incorrect.","error"); return redirect(url_for("settings"))
    db.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(new),session["user_id"])); db.commit(); db.close()
    flash("Password changed successfully.","success"); return redirect(url_for("settings"))

@app.route("/backup")
@login_required
@admin_required
def backup():
    """Download a local SQLite backup when using SQLite; PostgreSQL backups are handled by pg_dump/cloud backups."""
    from database import DATABASE_URL
    if DATABASE_URL:
        flash("PostgreSQL is active. Use the cloud database backup/pg_dump process for database backups.", "error")
        return redirect(url_for("settings"))
    db_path=BASE_DIR/"data"/"havilah_tech.db"
    if not db_path.exists():
        flash("Database file not found.","error"); return redirect(url_for("settings"))
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
    return send_file(str(db_path),as_attachment=True,download_name=f"havilah_tech_backup_{stamp}.db",mimetype="application/octet-stream")

if __name__=="__main__":
    app.run(debug=True,host="127.0.0.1",port=5000)
