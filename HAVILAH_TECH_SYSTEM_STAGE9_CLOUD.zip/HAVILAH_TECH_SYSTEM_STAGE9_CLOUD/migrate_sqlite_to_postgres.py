"""
Stage 5 SQLite -> PostgreSQL migration helper.

Usage:
  1. Create a PostgreSQL database.
  2. Set DATABASE_URL and SQLITE_SOURCE in your environment.
  3. Run: python migrate_sqlite_to_postgres.py

The script copies the Stage 4 tables and preserves IDs, settings, users,
products, services, stock movements, sales, sale items and expenses.
It does not delete the SQLite source.
"""
import os
import sqlite3
from pathlib import Path
import psycopg
from psycopg.rows import dict_row

from database import init_db, DATABASE_URL

SQLITE_SOURCE = Path(os.environ.get("SQLITE_SOURCE", "data/havilah_tech.db"))

TABLES = [
    "users", "services", "products", "stock_movements",
    "sales", "sale_items", "expenses", "settings"
]

def main():
    if not DATABASE_URL:
        raise SystemExit("DATABASE_URL is required.")
    if not SQLITE_SOURCE.exists():
        raise SystemExit(f"SQLite source not found: {SQLITE_SOURCE}")

    init_db()
    src = sqlite3.connect(SQLITE_SOURCE)
    src.row_factory = sqlite3.Row
    dst = psycopg.connect(DATABASE_URL)
    try:
        for table in TABLES:
            rows = src.execute(f"SELECT * FROM {table}").fetchall()
            if not rows:
                continue
            cols = rows[0].keys()
            col_sql = ", ".join(cols)
            placeholders = ", ".join(["%s"] * len(cols))
            # Existing Stage 5 tables are cleared in dependency order.
            # Settings/users/etc. will then be restored from the source.
            if table == "settings":
                dst.execute("DELETE FROM settings")
            elif table == "sale_items":
                dst.execute("DELETE FROM sale_items")
            elif table == "sales":
                dst.execute("DELETE FROM sales")
            elif table == "stock_movements":
                dst.execute("DELETE FROM stock_movements")
            elif table == "expenses":
                dst.execute("DELETE FROM expenses")
            elif table == "products":
                dst.execute("DELETE FROM products")
            elif table == "services":
                dst.execute("DELETE FROM services")
            elif table == "users":
                dst.execute("DELETE FROM users")
            for row in rows:
                dst.execute(
                    f"INSERT INTO {table} ({col_sql}) VALUES ({placeholders})",
                    tuple(row[c] for c in cols)
                )
            print(f"Migrated {len(rows):,} rows from {table}")
        # Restore PostgreSQL sequences after preserving SQLite IDs.
        for table in ["users","services","products","stock_movements","sales","sale_items","expenses"]:
            dst.execute(
                f"SELECT setval(pg_get_serial_sequence('{table}', 'id'), COALESCE((SELECT MAX(id) FROM {table}), 1), true)"
            )
        dst.commit()
        print("Migration completed successfully.")
    except Exception:
        dst.rollback()
        raise
    finally:
        src.close()
        dst.close()

if __name__ == "__main__":
    main()
