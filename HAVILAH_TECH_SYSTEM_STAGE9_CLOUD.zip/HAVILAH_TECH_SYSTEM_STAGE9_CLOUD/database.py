import os
import sqlite3
from pathlib import Path
from werkzeug.security import generate_password_hash

try:
    import psycopg
    from psycopg.rows import dict_row
    from psycopg import Error as PsycopgError
    from psycopg.errors import IntegrityError as PsycopgIntegrityError
except ImportError:  # PostgreSQL support is optional for local SQLite-only use
    psycopg = None
    dict_row = None
    class PsycopgError(Exception):
        pass
    class PsycopgIntegrityError(Exception):
        pass

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_FILE = DATA_DIR / "havilah_tech.db"

# Set DATABASE_URL to a PostgreSQL connection string for cloud/production use.
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql://" + DATABASE_URL[len("postgres://"):]

DEFAULT_SETTINGS = {
    "business_name": "HAVILAH TECH CYBER SERVICES",
    "business_phone": "",
    "business_email": "",
    "business_address": "",
    "receipt_footer": "Thank you for your business.",
    "receipt_watermark": "HAVILAH TECH CYBER",
    "logo_filename": "",
}

DB_ERROR = (sqlite3.Error, PsycopgError)
DB_INTEGRITY_ERROR = (sqlite3.IntegrityError, PsycopgIntegrityError)

def _qmark_to_postgres(sql):
    """Convert the project's SQLite-style ? placeholders to psycopg %s placeholders."""
    return sql.replace("?", "%s")

class PostgresDB:
    """Small compatibility wrapper so the existing Stage 4 app can use PostgreSQL."""
    def __init__(self, conn):
        self.conn = conn

    def execute(self, sql, params=()):
        return self.conn.execute(_qmark_to_postgres(sql), params)

    def executemany(self, sql, seq_of_params):
        return self.conn.executemany(_qmark_to_postgres(sql), seq_of_params)

    def executescript(self, sql):
        # Used only during PostgreSQL initialization with statements separated by semicolons.
        for statement in [s.strip() for s in sql.split(";") if s.strip()]:
            self.conn.execute(statement)

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()

def get_db():
    if DATABASE_URL:
        if psycopg is None:
            raise RuntimeError("PostgreSQL is configured but psycopg is not installed. Run: pip install -r requirements.txt")
        conn = psycopg.connect(DATABASE_URL, row_factory=dict_row, connect_timeout=10)
        return PostgresDB(conn)
    DATA_DIR.mkdir(exist_ok=True)
    db = sqlite3.connect(DB_FILE)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db

def _init_postgres(db):
    schema = """
    CREATE TABLE IF NOT EXISTS users (
        id BIGSERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Cashier',
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS services (
        id BIGSERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT DEFAULT '',
        price NUMERIC(14,2) NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS products (
        id BIGSERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        sku TEXT DEFAULT '',
        price NUMERIC(14,2) NOT NULL DEFAULT 0,
        stock_qty NUMERIC(14,3) NOT NULL DEFAULT 0,
        low_stock_level NUMERIC(14,3) NOT NULL DEFAULT 5,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS stock_movements (
        id BIGSERIAL PRIMARY KEY,
        product_id BIGINT NOT NULL REFERENCES products(id),
        movement_type TEXT NOT NULL,
        quantity NUMERIC(14,3) NOT NULL,
        balance_after NUMERIC(14,3) NOT NULL,
        reference TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        created_by BIGINT REFERENCES users(id),
        created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS sales (
        id BIGSERIAL PRIMARY KEY,
        receipt_no TEXT NOT NULL UNIQUE,
        subtotal NUMERIC(14,2) NOT NULL DEFAULT 0,
        discount NUMERIC(14,2) NOT NULL DEFAULT 0,
        total NUMERIC(14,2) NOT NULL DEFAULT 0,
        payment_method TEXT NOT NULL DEFAULT 'Cash',
        created_by BIGINT REFERENCES users(id),
        created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS sale_items (
        id BIGSERIAL PRIMARY KEY,
        sale_id BIGINT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
        item_type TEXT NOT NULL,
        item_id BIGINT,
        item_name TEXT NOT NULL,
        quantity NUMERIC(14,3) NOT NULL DEFAULT 1,
        unit_price NUMERIC(14,2) NOT NULL DEFAULT 0,
        line_total NUMERIC(14,2) NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS expenses (
        id BIGSERIAL PRIMARY KEY,
        description TEXT NOT NULL,
        amount NUMERIC(14,2) NOT NULL DEFAULT 0,
        category TEXT DEFAULT '',
        created_by BIGINT REFERENCES users(id),
        created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL DEFAULT ''
    );
    """
    db.executescript(schema)
    # Payment state is kept on the sale so reports never treat a failed/pending
    # M-PESA checkout as completed revenue. Existing rows default to PAID.
    db.execute("ALTER TABLE sales ADD COLUMN IF NOT EXISTS payment_status TEXT NOT NULL DEFAULT 'PAID'")
    db.execute("ALTER TABLE sales ADD COLUMN IF NOT EXISTS mpesa_receipt TEXT DEFAULT ''")
    db.execute("ALTER TABLE sales ADD COLUMN IF NOT EXISTS mpesa_phone TEXT DEFAULT ''")
    db.execute("""
        CREATE TABLE IF NOT EXISTS mpesa_transactions (
            id BIGSERIAL PRIMARY KEY,
            sale_id BIGINT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
            merchant_request_id TEXT DEFAULT '',
            checkout_request_id TEXT NOT NULL UNIQUE,
            phone TEXT NOT NULL,
            amount NUMERIC(14,2) NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING',
            mpesa_receipt TEXT DEFAULT '',
            result_code TEXT DEFAULT '',
            result_description TEXT DEFAULT '',
            raw_callback TEXT DEFAULT '',
            created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

def init_db():
    db = get_db()
    try:
        if DATABASE_URL:
            _init_postgres(db)
            # PostgreSQL syntax
            if db.execute("SELECT id FROM users WHERE username=%s", ("admin",)).fetchone() is None:
                db.execute(
                    "INSERT INTO users(username,password_hash,full_name,role) VALUES(%s,%s,%s,%s)",
                    ("admin", generate_password_hash("admin123"), "System Administrator", "Administrator")
                )
            if db.execute("SELECT COUNT(*) AS c FROM services").fetchone()["c"] == 0:
                db.executemany(
                    "INSERT INTO services(name,description,price) VALUES(%s,%s,%s)",
                    [("Computer Services","General computer services",100),
                     ("Printing","Black and white printing",20),
                     ("Photocopy","Document photocopying",10)]
                )
            if db.execute("SELECT COUNT(*) AS c FROM products").fetchone()["c"] == 0:
                db.executemany(
                    "INSERT INTO products(name,sku,price,stock_qty,low_stock_level) VALUES(%s,%s,%s,%s,%s)",
                    [("A4 Paper","PAPER-A4",10,100,20),
                     ("USB Flash Disk 32GB","USB-32",800,10,3)]
                )
                for p in db.execute("SELECT id,stock_qty FROM products").fetchall():
                    if p["stock_qty"]:
                        db.execute(
                            """INSERT INTO stock_movements
                            (product_id,movement_type,quantity,balance_after,reference,notes)
                            VALUES(%s,%s,%s,%s,%s,%s)""",
                            (p["id"],"OPENING",p["stock_qty"],p["stock_qty"],"OPENING","Opening stock")
                        )
            for key, value in DEFAULT_SETTINGS.items():
                db.execute("INSERT INTO settings(key,value) VALUES(%s,%s) ON CONFLICT(key) DO NOTHING", (key, value))
        else:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                full_name TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'Cashier',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT DEFAULT '',
                price REAL NOT NULL DEFAULT 0,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                sku TEXT DEFAULT '',
                price REAL NOT NULL DEFAULT 0,
                stock_qty REAL NOT NULL DEFAULT 0,
                low_stock_level REAL NOT NULL DEFAULT 5,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS stock_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                movement_type TEXT NOT NULL,
                quantity REAL NOT NULL,
                balance_after REAL NOT NULL,
                reference TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                created_by INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(product_id) REFERENCES products(id),
                FOREIGN KEY(created_by) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                receipt_no TEXT NOT NULL UNIQUE,
                subtotal REAL NOT NULL DEFAULT 0,
                discount REAL NOT NULL DEFAULT 0,
                total REAL NOT NULL DEFAULT 0,
                payment_method TEXT NOT NULL DEFAULT 'Cash',
                payment_status TEXT NOT NULL DEFAULT 'PAID',
                mpesa_receipt TEXT DEFAULT '',
                mpesa_phone TEXT DEFAULT '',
                created_by INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(created_by) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS sale_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                item_type TEXT NOT NULL,
                item_id INTEGER,
                item_name TEXT NOT NULL,
                quantity REAL NOT NULL DEFAULT 1,
                unit_price REAL NOT NULL DEFAULT 0,
                line_total REAL NOT NULL DEFAULT 0,
                FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,
                amount REAL NOT NULL DEFAULT 0,
                category TEXT DEFAULT '',
                created_by INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(created_by) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS mpesa_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                merchant_request_id TEXT DEFAULT '',
                checkout_request_id TEXT NOT NULL UNIQUE,
                phone TEXT NOT NULL,
                amount REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'PENDING',
                mpesa_receipt TEXT DEFAULT '',
                result_code TEXT DEFAULT '',
                result_description TEXT DEFAULT '',
                raw_callback TEXT DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE
            );
            """)
            # Upgrade an older Stage 5 database created before M-PESA fields existed.
            existing_cols = {r['name'] for r in db.execute("PRAGMA table_info(sales)").fetchall()}
            if 'payment_status' not in existing_cols:
                db.execute("ALTER TABLE sales ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'PAID'")
            if 'mpesa_receipt' not in existing_cols:
                db.execute("ALTER TABLE sales ADD COLUMN mpesa_receipt TEXT DEFAULT ''")
            if 'mpesa_phone' not in existing_cols:
                db.execute("ALTER TABLE sales ADD COLUMN mpesa_phone TEXT DEFAULT ''")
            if db.execute("SELECT id FROM users WHERE username='admin'").fetchone() is None:
                db.execute(
                    "INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?,?)",
                    ("admin", generate_password_hash("admin123"), "System Administrator", "Administrator")
                )
            if db.execute("SELECT COUNT(*) c FROM services").fetchone()["c"] == 0:
                db.executemany(
                    "INSERT INTO services(name,description,price) VALUES(?,?,?)",
                    [("Computer Services","General computer services",100),
                     ("Printing","Black and white printing",20),
                     ("Photocopy","Document photocopying",10)]
                )
            if db.execute("SELECT COUNT(*) c FROM products").fetchone()["c"] == 0:
                db.executemany(
                    "INSERT INTO products(name,sku,price,stock_qty,low_stock_level) VALUES(?,?,?,?,?)",
                    [("A4 Paper","PAPER-A4",10,100,20),
                     ("USB Flash Disk 32GB","USB-32",800,10,3)]
                )
                for p in db.execute("SELECT id,stock_qty FROM products").fetchall():
                    if p["stock_qty"]:
                        db.execute(
                            """INSERT INTO stock_movements
                            (product_id,movement_type,quantity,balance_after,reference,notes)
                            VALUES(?,?,?,?,?,?)""",
                            (p["id"],"OPENING",p["stock_qty"],p["stock_qty"],"OPENING","Opening stock")
                        )
            for key, value in DEFAULT_SETTINGS.items():
                db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key, value))
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def get_settings(db=None):
    own = db is None
    db = db or get_db()
    rows = db.execute("SELECT key,value FROM settings").fetchall()
    result = DEFAULT_SETTINGS.copy()
    result.update({r["key"]: r["value"] for r in rows})
    if own:
        db.close()
    return result
