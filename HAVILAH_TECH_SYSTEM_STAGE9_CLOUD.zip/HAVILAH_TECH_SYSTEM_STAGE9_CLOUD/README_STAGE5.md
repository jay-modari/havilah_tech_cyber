# HAVILAH TECH CYBER SERVICES — Stage 5

Stage 5 converts the Stage 4 Flask application into a **cloud-ready application** while keeping SQLite available for local development.

## What changed

- PostgreSQL support through `psycopg`
- `DATABASE_URL` environment configuration
- SQLite remains available when `DATABASE_URL` is empty
- PostgreSQL schema initialization
- SQLite → PostgreSQL migration helper
- Production WSGI entrypoint using Gunicorn
- `Procfile` for Railway/Render-style deployment
- Production session-cookie security settings
- `/health` endpoint for deployment health checks
- Local SQLite backup remains available
- PostgreSQL backup message points to `pg_dump`/managed-cloud backups
- Existing Stage 4 POS, inventory, services, expenses, reports, users, settings and PDF receipt features retained

## Local testing

```powershell
cd "C:\Users\CHILE\Downloads\HAVILAH_TECH_SYSTEM_STAGE5"
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python run.py
```

Open:

`http://127.0.0.1:5000`

Default login:

- Username: `admin`
- Password: `admin123`

Change the administrator password after first login.

## PostgreSQL mode

Create a PostgreSQL database, then set:

```text
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME
HAVILAH_SECRET_KEY=<long-random-secret>
SESSION_COOKIE_SECURE=1
```

The application creates the required tables automatically at startup.

## Migrating an existing Stage 4 SQLite database

Copy your Stage 4 `data/havilah_tech.db` into the Stage 5 `data` folder, or point to it with:

```powershell
$env:SQLITE_SOURCE="C:\path\to\havilah_tech.db"
$env:DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/DBNAME"
python migrate_sqlite_to_postgres.py
```

The migration copies users, services, products, stock movements, sales, sale items, expenses and settings and preserves their IDs.

## Production

Gunicorn is configured through:

```text
web: gunicorn --workers 2 --threads 4 --timeout 120 --bind 0.0.0.0:$PORT run:app
```

Do not use Flask's development server as the public production server.

## Next stage

Stage 6 can add:

1. GitHub repository setup
2. Managed PostgreSQL creation
3. Railway or Render deployment
4. Environment-variable configuration
5. HTTPS/public URL
6. Custom domain
7. Production logging and monitoring

After the cloud deployment is stable, Stage 7 can add the Safaricom Daraja M-PESA sandbox integration.


## Stage 6/7 — Daraja M-PESA Express integration

This package now contains the Havilah Daraja integration layer. Safaricom's current Daraja 3.0 portal provides an Authorization API and M-PESA Express (Prompt) for initiating customer payment prompts.

### What is included

- POS M-PESA payment option
- Kenyan phone-number normalization (`07...`, `+254...`, `254...`)
- Daraja OAuth access-token request
- STK Push request
- Public `/mpesa/callback` endpoint
- M-PESA transaction table and payment status
- Pending / successful / failed payment states
- Stock is reduced **only after a successful M-PESA callback**
- M-PESA receipt number is stored against the sale
- POS waits for confirmation and provides a receipt link after success
- Sales/reports count only `PAID` sales as completed revenue
- Transaction-status API remains a suitable later reconciliation addition when callbacks are delayed.

### Configure sandbox

Copy `.env.example` to `.env` (or set the same variables in your hosting provider). Create a sandbox app in the official Daraja portal to obtain the Consumer Key and Consumer Secret. Safaricom's documentation says sandbox apps can be tested with the Daraja simulator.

Set:

```text
MPESA_ENV=sandbox
MPESA_CONSUMER_KEY=your_sandbox_consumer_key
MPESA_CONSUMER_SECRET=your_sandbox_consumer_secret
MPESA_SHORTCODE=your_sandbox_shortcode
MPESA_PASSKEY=your_sandbox_passkey
MPESA_CALLBACK_URL=https://YOUR_PUBLIC_DOMAIN/mpesa/callback
MPESA_TRANSACTION_TYPE=CustomerBuyGoodsOnline
```

For a PayBill integration, use `CustomerPayBillOnline` instead. The callback URL must be publicly reachable when Daraja is calling the deployed application.

### Important

Do not put Consumer Secrets, Passkeys or production credentials into source files or commit them to GitHub. Keep them in environment variables/secrets on the deployment platform.

The package is **Daraja-ready**, but it cannot send a real M-PESA prompt until you supply valid Daraja credentials and a reachable callback URL. Live payments also require Safaricom's production/go-live process; the official documentation distinguishes sandbox testing from live PayBill/Till setup.

### Next technical stage

The next production step is **cloud deployment first**, because the Daraja callback needs a public endpoint. After the app has a public HTTPS URL, configure the callback URL, run sandbox tests, then proceed through Safaricom's go-live process for the real Till/PayBill.


## Stage 6/7 M-PESA configuration

The Havilah POS is configured for a Buy Goods Till integration. The supplied merchant Till is **9240308** and the merchant name is **Godfrey Ochelle**.

Keep the live Consumer Key, Consumer Secret and Passkey outside the source code using environment variables. The default transaction type is `CustomerBuyGoodsOnline`.

For production, Safaricom requires the callback URL to be publicly reachable; production URLs must use HTTPS. Daraja's C2B documentation also identifies a Till as a short code and `CustomerBuyGoodsOnline` as the transaction type for Till payments.

## Stage 9 — Cloud deployment package

This package includes `railway.json` configured for Gunicorn, `/health` deployment health checks, and restart-on-failure. See `DEPLOYMENT_STAGE9.md` for the Railway + PostgreSQL + HTTPS + Daraja callback setup.
